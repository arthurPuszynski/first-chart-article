JSC.Chart('chartDiv', {
	type: 'horizontal column',
	series: [
		{
			name: 'Andy',
			points: [
				{x: 'Apples', y: 50},
				{x: 'Oranges', y: 32}
			]
		}, {
			name: 'Anna',
			points: [
				{x: 'Apples', y: 30},
				{x: 'Oranges', y: 22}
			]
		}
	]
});
